﻿using UnityEngine;
using System.Collections;

public class LaserCollision : MonoBehaviour {

	private bool collided;

	void Start() {
		collided = false;
	}

	void OnTriggerEnter(Collider col){

		col = GetComponent<Collider>();
		print (col.name);

		if (col.name == "LaserSphere")
			collided = true;
		else
			collided = false;
	}

	public void OnUpdate(){
		if (collided) {
			GetComponent<Renderer> ().material.shader = Shader.Find ("ImageEffectShader");
		} else {
			GetComponent<Renderer> ().material.shader = Shader.Find ("Diffuse");
		}
	}


}
