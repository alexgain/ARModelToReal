﻿using UnityEngine;
using System.Collections;

public class LaserControl : MonoBehaviour {

	bool select_var;
	bool cal_bool;
	ArrayList modeList = new ArrayList();
	int modeInt;

	public float laserSpeed = 5f;
	Vector3 temp;

	// Use this for initialization
	void Start () {
		modeInt = 0;
		modeList.Add("Translation");
		modeList.Add("Scale");
		modeList.Add("Opacity");
		modeList.Add("Rotation");
		//Rect rect = new Rect (0, 0, 100, 50);
		//GUI.TextArea (rect, "Joystick Mode: " + modeList[modeInt]);
		select_var = false;
		cal_bool = false;
	}
	
	// Update is called once per frame
	void Update () {

		//Updating modeInt if needed:
		if (Input.GetKeyDown (KeyCode.P)) {
			if (modeInt == 3) {
				modeInt = 0;
			} else
				modeInt = modeInt + 1;
		
		}

		//Only modify laser if in translation mode:
		if (modeInt==0) {
			float l_input = System.Convert.ToSingle (Input.GetKey (KeyCode.Q)) - System.Convert.ToSingle (Input.GetKey (KeyCode.E));

			temp = transform.localScale;

			temp.z += l_input * laserSpeed * Time.deltaTime;

			if (temp.z < 0.2f) {
				temp.z = 0.2f;
			}

			if (temp.z > 4) {
				temp.z = 4;
			}

	
			transform.localScale = temp;

		}

		//Calibration:
		if (Input.GetKeyDown (KeyCode.O)) {
			cal_bool = !cal_bool;

		}


		//GUI.TextArea (new Rect (0, 0, 100, 50), "Joystick Mode: " + modeList [modeInt]);



	}

	void OnGUI(){
		if (!cal_bool){
			GUI.TextArea (new Rect (0, 0, 100, 50), "Joystick Mode: " + modeList [modeInt]);
		}
	
	}

	void OnTriggerEnter(Collider other){
		select_var = true;

	}

	void OnTriggerStay(Collider other){

		//Updating selection variable:
//		if (select_var ==false && Input.GetKeyDown (KeyCode.C)) {
//			select_var = true;
//		}
		select_var = true;

	}

	void OnTriggerExit(Collider other){

		select_var = false;
	}

}
