﻿using UnityEngine;
using System.Collections;

public class TriggerController : MonoBehaviour {

	void OnTriggerEnter (Collider other) {
		print ("Object Entered the trigger.");
		Debug.Log ("Object Entered the trigger.");
	
	}
	
	void OnTriggerStay (Collider other) {
		print ("Object is within trigger.");
		Debug.Log ("Object is within trigger.");

	}

	void OnTriggerExit (Collider other) {
		print ("Object exited the trigger.");
		Debug.Log ("Object exited the trigger.");

	}

}
