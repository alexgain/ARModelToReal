﻿using UnityEngine;
using System.Collections;

public class CubeController : MonoBehaviour {

	public float moveSpeed;
	public float rotateSpeed;
	bool cal_bool;

	// Use this for initialization
	void Start () {
		moveSpeed = 1f;
		rotateSpeed = 100f;
		bool cal_bool = false;
	
	}
	
	// Update is called once per frame
	void Update () 

	{
		float x_input = Input.GetAxis ("Horizontal");
		float z_input = Input.GetAxis ("Vertical");

		float x_input2 = System.Convert.ToSingle(Input.GetKey (KeyCode.I)) - System.Convert.ToSingle(Input.GetKey (KeyCode.K));
		float z_input2 = System.Convert.ToSingle(Input.GetKey (KeyCode.L)) - System.Convert.ToSingle(Input.GetKey (KeyCode.J));

		float dt = Time.deltaTime;

		//Translation:
//		transform.Translate (moveSpeed * x_input * dt, 0f, moveSpeed* z_input * dt);
		transform.Translate (0f, 0f, moveSpeed * z_input * dt);
	
		//Rotation:
		transform.Rotate(rotateSpeed * x_input2 * dt, rotateSpeed * z_input2 * dt, rotateSpeed * x_input * dt);

		//Calibration:
		if (Input.GetKeyDown (KeyCode.O)) {
			cal_bool = !cal_bool;

		}
		if (cal_bool) {
			transform.position = new Vector3(0.0f, 0.0f, 0.0f);
			transform.rotation = Quaternion.identity;;
				
		}
	}

	void OnGUI(){
		if (cal_bool) {
			GUI.TextArea (new Rect (100, 100, 125, 125), "Please calibrate controller. Press O when finished.");
		}

	}


}
