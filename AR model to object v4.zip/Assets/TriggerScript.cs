﻿using UnityEngine;
using System.Collections;

public class TriggerScript : MonoBehaviour {

	bool select_var = false;
	ArrayList modeList = new ArrayList();
	int modeInt;
	public float scaleSpeed = 5;
	public float opacitySpeed = 0.1f;
	Vector3 temp;

	// Needed to work with different modes:
	void Start () {
		modeInt = 0;
		modeList.Add("Translation");
		modeList.Add("Scale");
		modeList.Add("Opacity");

	}

	// Needed to possibly change mode:
	void Update () {
		//Updating modeInt if needed:
		if (Input.GetKeyDown (KeyCode.P)) {
			if (modeInt == 2) {
				modeInt = 0;
			} else
				modeInt = modeInt + 1;

		}

	}

	void OnTriggerEnter(Collider other) 
	{

		//other.gameObject.SetActive (false);
		//other.GetComponent<MeshRenderer> ().material.shader = Shader.Find ("ImageEffectShader");
		Color yellowColor = new Color();
		yellowColor.r = 1.0f; yellowColor.g = 1.0f; yellowColor.b = 0.0f;
		float opac = other.GetComponent<MeshRenderer> ().material.color.a;
		yellowColor.a = opac;

		other.GetComponent<MeshRenderer>().material.color = yellowColor;



	}

	void OnTriggerStay(Collider other)
	{

		//Updating selection variable:
		if (Input.GetKeyDown (KeyCode.C)) {
			select_var = !select_var;
		}

		//Updating scaling for Scaling mode:
		if (select_var && modeInt==1) {

			float scaleDirection = System.Convert.ToSingle (Input.GetKey (KeyCode.Q)) - System.Convert.ToSingle (Input.GetKey (KeyCode.E));

			float dt = Time.deltaTime;
			temp.x = other.transform.localScale.x + scaleDirection * scaleSpeed * dt * 1.0f;
			temp.y = other.transform.localScale.x + scaleDirection * scaleSpeed * dt * 1.0f;
			temp.z = other.transform.localScale.x + scaleDirection * scaleSpeed * dt * 1.0f;
			if (temp.x < 0.7) {
				temp.x = 0.7f;
			}

			if (temp.x > 4) {
				temp.x = 4.0f;
			}

			if (temp.x > 4) {
				temp.x = 4.0f;
			}

			if (temp.x > 4) {
				temp.x = 4.0f;
			}

			if (temp.x > 4) {
				temp.x = 4.0f;
			}

			if (temp.x < 0.7) {
				temp.x = 0.7f;
			}


			other.transform.localScale = temp;

//			other.transform.localScale.x += scaleDirection * scaleSpeed * 1.0f;
//			other.transform.localScale.y += scaleDirection * scaleSpeed * 1.0f;
//			other.transform.localScale.z += scaleDirection * scaleSpeed * 1.0f;
		}

		//Updating opacity if opacity mode selected:
		if (select_var && modeInt==2) {

			float opacityDirection = System.Convert.ToSingle (Input.GetKey (KeyCode.Q)) - System.Convert.ToSingle (Input.GetKey (KeyCode.E));

			float dt = Time.deltaTime;

			var color = other.GetComponent<MeshRenderer>().material.color; 
			var newColor = new Color();
			newColor.r = other.GetComponent<MeshRenderer> ().material.color.r; newColor.g = other.GetComponent<Renderer> ().material.color.g; newColor.b = other.GetComponent<Renderer> ().material.color.b;
			newColor.a = other.GetComponent<MeshRenderer>().material.color.a +  opacityDirection * opacitySpeed * dt * 1.0f;

			if (newColor.a < 0.1) {
				newColor.a = 0.1f;
			}

			if (newColor.a > 1.0) {
				newColor.a = 1.0f;
			}


			other.GetComponent<MeshRenderer>().material.color = newColor;



		}


		//Updating position if selected:
		if (select_var) {
			other.transform.position = transform.position;
		}



	}


	void OnTriggerExit(Collider other) 
	{
		Color blueColor = new Color();
		blueColor.r = 0.255f; blueColor.g = 0.412f; blueColor.b = 0.882f;
		float opac = other.GetComponent<MeshRenderer> ().material.color.a;
		blueColor.a = opac;
		other.GetComponent<MeshRenderer>().material.color = blueColor;

		select_var = false;

		//other.GetComponent<MeshRenderer> ().material.shader = Shader.Find ("Diffuse");

	}


}
