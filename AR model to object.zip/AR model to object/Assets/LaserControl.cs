﻿using UnityEngine;
using System.Collections;

public class LaserControl : MonoBehaviour {

	public float laserSpeed = 5f;
	Vector3 temp;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		float l_input = System.Convert.ToSingle(Input.GetKey (KeyCode.Q)) - System.Convert.ToSingle(Input.GetKey (KeyCode.E));

		temp = transform.localScale;

		temp.z += l_input * laserSpeed * Time.deltaTime;

		if (temp.z < 0) {
			temp.z = 0;
		}

		if (temp.z > 4) {
			temp.z = 4;
		}

	
		transform.localScale = temp;

	}
}
