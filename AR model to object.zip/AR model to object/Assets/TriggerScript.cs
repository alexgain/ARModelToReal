﻿using UnityEngine;
using System.Collections;

public class TriggerScript : MonoBehaviour {

	bool select_var = false;

	void OnTriggerEnter(Collider other) 
	{

		//other.gameObject.SetActive (false);
		other.GetComponent<Renderer> ().material.shader = Shader.Find ("ImageEffectShader");


	}

	void OnTriggerStay(Collider other)
	{

		if (select_var) {
			other.transform.position = transform.position;
		}
		

		if (Input.GetKeyDown (KeyCode.C)) {
			select_var = !select_var;
		}

	}


	void OnTriggerExit(Collider other) 
	{

		//other.gameObject.SetActive (false);
		other.GetComponent<Renderer> ().material.shader = Shader.Find ("Diffuse");
	}


}
